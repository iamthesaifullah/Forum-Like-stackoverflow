


<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="style.css">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>ProgrammingBlogForum</title>
    <style>
      
    </style>
  </head>
  <body>
      <?php include 'partials/db_connect.php'; ?>
    <?php include 'partials/header.php';  ?>



<div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
  </div>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img class="s"src="img/1.jpg" class="d-block w-100" alt="...">
      <div class="carousel-caption d-none d-md-block">
        <h5>The Programming Blog</h5>
        <p>its from programing blog modifaction for support users to help each others.</p>
      </div>
    </div>
    <div class="carousel-item">
      <img src="img/1.jpg" class="d-block w-100" alt="...">
      <div class="carousel-caption d-none d-md-block">
        <h5>MD.SAIFULLAH AL MAHMUD </h5>
        <p>FULL STACK WEB DEVELOPER.</p>
      </div>
    </div>
    <div class="carousel-item">
      <img src="img/1.jpg" class="d-block w-100" alt="...">
      <div class="carousel-caption d-none d-md-block">
        <h5>This forum fully based on Php & Database</h5>
        <p>Some representative placeholder content for the third slide.</p>
      </div>
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
    
  <div class="container">
      <h2 class="text-center">Programming Blog Forum  Browse: categories</h2>
      <div class="row">
          <?php
          include 'partials/db_connect.php';
          $sql ="Select * from categories";
          $result = mysqli_query($conn,$sql);
          while($row=mysqli_fetch_assoc($result)){
              $catid=$row['cat_id'];
              $cat_dt=$row['cat_date'];
              $cat_nam=$row['cat_name'];
              $cat_des=$row['cat_desc'];
      echo'<div class="col-md-4 my-2 ml-2">
          
<div class="card py-2" style="width: 18rem;">
  <img src="img/2.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">'.$cat_nam.'</h5>
    <p class="card-text">'.substr($cat_des,0,60).'</p>
      <hr>
      <strong>Submitted on : '.$cat_dt.'</strong>
      <hr>
    <a href="threadlist.php?catid='.$catid.'" class="btn btn-dark">View Category</a>
  </div>
</div>
      </div>';
          }
         ?>

<!-- Button trigger modal -->
    <!-- Optional JavaScript; choose one of the two! -->
    <?php include 'partials/footer.php';  ?>

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

    
  </body>
</html>