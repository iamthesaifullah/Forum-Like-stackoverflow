<?php 

echo '<div class="container-fluid s">
    <p class="text-center">©all rights Reserved By SAIFULLAH AL MAHMUD</p>
</div>';




?>