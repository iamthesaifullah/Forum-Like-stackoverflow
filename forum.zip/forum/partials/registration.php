<?php 

include 'db_connect.php';

if($_SERVER['REQUEST_METHOD']=='POST'){
    
  
    $email = $_POST["email"];
    $username = $_POST['username'];
    $password = $_POST["password"];
    $cpassword = $_POST['cpassword'];

    $existssql = "select * from `registrarion` where email = '$email'";
    $result = mysqli_query($conn, $existssql);
    $numexitrows = mysqli_num_rows($result);
    if ($numexitrows>0){
      	echo "email already exists";
    }
    else{

      if($password == $cpassword ){
        $hash = password_hash($password,PASSWORD_DEFAULT);
        $sql = "INSERT INTO `registrarion` (`email`, `username`, `password`) VALUES ('$email', '$username', '$hash')";
        $result = mysqli_query($conn, $sql);
        if($result){
         	echo "Successful Entry Details";
        }
        else{
            echo"information wrong".mysqli_connect_error($result);    
          }
      }

    }
}

?>




















