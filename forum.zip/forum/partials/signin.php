<?php

if($_SERVER['REQUEST_METHOD']=='POST'){
    
    include 'db_connect.php';
    $email = $_POST["email"];
    $password = $_POST["password"];
    
    
    $sql = "Select * from `registrarion` where email= '$email'";
    
    $result = mysqli_query($conn, $sql);
    $num = mysqli_num_rows($result);
    if($num==1){
        while($row=mysqli_fetch_assoc($result)){
            if(password_verify($password,$row['password'])){
                $login=true;
                session_start();
                $_SESSION['loggedin']=True;
                $_SESSION['email']=$email;
                
                header("location:../index.php");
                echo "successful ";
          }
        }
    }
    else{
        echo "Invalid Credentials";
    }
    


}

?>