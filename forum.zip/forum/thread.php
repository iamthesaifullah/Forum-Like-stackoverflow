
<!doctype html>    
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
<link rel="stylesheet" href="style.css">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>ProgrammingBlogForum</title>
  </head>
  <body>
    <?php include 'partials/db_connect.php';?>

    <?php include 'partials/header.php';  ?>
    
<?php     
    $id =$_GET['threadid'];
    $noresult=true;
  $sql ="Select * from threads where thread_id =$id";
          $result = mysqli_query($conn,$sql);
          while($row=mysqli_fetch_assoc($result)){
              $noresult=false;
              
              $title=$row['thread_title'];
              $des=$row['thread_desc'];
    
    
          }
          if($noresult){
              echo '<div class="alert alert-warning alert-dismissible fade show" role="alert">
  <strong>No Answers Yet!</strong> please help him
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>';
          }
   ?>
    
    
    
    
    
    
    
    
    
    <div class="conatainer my-0">
<div class="alert alert-success" role="alert">
  <h4 class="alert-heading"><?php echo $title ?></h4>
  <p><?php echo $des ?></p>
  <hr>
  
</div>
</div>
<div class="container">
    <h3 class="py-2">Discussion of your Question : </h3>
    
    
    
    
    
    
    <?php 
    $showalert=false;
    $method=$_SERVER['REQUEST_METHOD'];
    if($method=='POST'){
        
        $content=$_POST['comment_content'];
        
        $sql="INSERT INTO `comments` (`comment_content`, `thread_id`, `comment_by_id`, `comment_time`) VALUES ('$content', '$id', '5', current_timestamp());";
        $result= mysqli_query($conn,$sql);
        $showalert=true;
        if($showalert){
              
              echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
  <strong>Successful!</strong>Your ans 
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>';
          }
       
    }
    
    
    ?>
    
    
    
    
    

<div class="container">
  <h3>Ask Your Questions here....</h3>  
    <form action="<?php echo  $_SERVER['REQUEST_URI'] ?>" method="post">
        
<div class="mb-3">
<div class="mb-3">
  <label for="exampleFormControlTextarea1" class="form-label">answer this question : ...</label>
  <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" name="comment_content"></textarea>
</div>
<div class="mb-3">
    <button type="submit" class="btn btn-success mb-3">Submit</button>
  </div>
        
        
    </form>
</div>
    

    
    
<?php     
    $id =$_GET['threadid'];
    $nothread=true;
  $sql ="Select * from comments where thread_id =$id";
          $result = mysqli_query($conn,$sql);
          while($row=mysqli_fetch_assoc($result)){
              $nothread=false;
              $id=$row['comment_id'];
              $ans=$row['comment_content'];
              $by=$row['comment_by_id'];
              $dt=$row['comment_time'];
              $userid=$row['comment_by_id'];
              $sqls="SELECT * FROM `registrarion`  where sno='$by'";
              $res = mysqli_query($conn,$sqls);
              $row2 =mysqli_fetch_assoc($res);
              echo '
<div class="media my-3">
  <img src="img/user.png" width="64px" class="mr-3" alt="...">
  <h3>Comment by : '.$row2['username'].' </h3>
  <div class="media-body">
 <div class="alert alert-primary d-flex align-items-center" role="alert">
  <svg class="bi flex-shrink-0 me-2" width="24" height="24" role="img" aria-label="Info:"><use xlink:href="#info-fill"/></svg>
  <div>
    '.$ans.'
  </div>
</div>
   <strong>Submitted on : '.$dt.'<strong>
  </div>
</div>
    ';
    
    
          }


   ?>
    
    
    

</div>

<nav aria-label="Page navigation example">
  <ul class="pagination">
    <li class="page-item"><a class="page-link" href="#">Previous</a></li>
    <li class="page-item"><a class="page-link" href="#">1</a></li>
    <li class="page-item"><a class="page-link" href="#">2</a></li>
    <li class="page-item"><a class="page-link" href="#">3</a></li>
    <li class="page-item"><a class="page-link" href="#">Next</a></li>
  </ul>
</nav>






<!-- Button trigger modal -->
    <!-- Optional JavaScript; choose one of the two! -->
    <?php include 'partials/footer.php';  ?>

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

    
  </body>
</html>