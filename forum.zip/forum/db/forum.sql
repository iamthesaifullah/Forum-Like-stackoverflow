-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 03, 2021 at 07:09 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `forum`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `cat_id` int(8) NOT NULL,
  `cat_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `cat_desc` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `cat_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`cat_id`, `cat_name`, `cat_desc`, `cat_date`) VALUES
(1, 'PYTHON', 'Python Is a high level language.\r\nMechine learning and all others operations you can do using python', '2021-07-07 07:55:08'),
(2, 'Java', 'Java Is a high level language.\r\nMechine learning and all others operations you can do using python', '2021-07-07 07:55:39'),
(3, 'PHP', 'OBJECT ORIENTENTED PROGRAMMING.\r\nPHP Is a high level language.\r\nMechine learning and all others operations you can do using PHP', '2021-07-07 07:56:29'),
(4, 'PYTHON FLASK ', 'IS A FRAMEWORK OF PYTHON\r\nPython Is a high level language.\r\nMechine learning and all others operations you can do using python FLASK', '2021-07-07 07:57:07'),
(5, 'Android development ', 'All the android problem you can write here...', '2021-07-13 19:14:55'),
(6, 'ios develop ', 'All the ios development  problem you can write here...', '2021-07-13 19:15:38'),
(7, 'Django Framework', 'Python Biggest platform for web developer The Django Framework..\r\nHowever, If you have any related problem here you can disscuss here', '2021-07-13 19:17:13'),
(8, 'Laravel Framework', 'Laravel Biggest platform for web developer The Laravel Framework..\r\nHowever, If you have any related problem here you can disscuss here', '2021-07-13 19:17:55'),
(9, 'Html', 'All html problem write and discussion here', '2021-07-13 19:18:32'),
(10, 'css', 'All css problem write and discussion here', '2021-07-13 19:18:51');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `comment_id` int(8) NOT NULL,
  `comment_content` text COLLATE utf8_unicode_ci NOT NULL,
  `thread_id` int(8) NOT NULL,
  `comment_by_id` int(11) NOT NULL,
  `comment_time` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`comment_id`, `comment_content`, `thread_id`, `comment_by_id`, `comment_time`) VALUES
(1, 'Pip install tensorflow \r\nYour file will be installed', 1, 1, '2021-07-16 12:05:25'),
(2, 'Nice', 2, 2, '2021-07-09 11:39:47'),
(3, 'The post banned', 1, 4, '2021-07-09 11:42:36'),
(4, 'Follow me on insta', 8, 5, '2021-07-09 11:43:56'),
(5, 'Tell me the description of your problem', 6, 6, '2021-07-09 12:20:39'),
(6, 'Clear both and built and run use that in java you can run your files.', 2, 3, '2021-07-09 18:24:35'),
(7, 'This test was success', 1, 1, '2021-07-09 19:31:38'),
(8, 'Try to github solution there was a file', 1, 2, '2021-07-10 08:35:18'),
(9, 'Visit github', 1, 5, '2021-07-10 19:13:20'),
(10, 'Please go to udemy there is a lot of course', 14, 5, '2021-07-13 19:20:18'),
(11, 'hi', 2, 5, '2021-07-31 23:21:07');

-- --------------------------------------------------------

--
-- Table structure for table `registrarion`
--

CREATE TABLE `registrarion` (
  `sno` int(8) NOT NULL,
  `email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `username` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(256) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `registrarion`
--

INSERT INTO `registrarion` (`sno`, `email`, `username`, `password`) VALUES
(1, 'Kaisarsaiful@gmail.com', 'Saiful', 'saiful12'),
(2, 'farabi@gmail.com', 'Farabi', 'sam'),
(3, 'samma@gmail.com', 'Nishi', 'loveyousaiful'),
(4, 'saiful@gmail.com', 'Arfat', '$2y$10$77zt8FcB7upnzeRWDeZszuBjTJPiHmZGshGhkteHTgvSdcu9ci37m'),
(5, 'nazmul.shishir75@gmail.com', 'Nazmul', '$2y$10$eGFDYhdeSvUsBlq2NuKi0uxWNTdonMEYrMwWKMx..fTw60gn70N8.'),
(6, 'saifultanim@gmail.com', 'Lehmann', '$2y$10$mt/PY7FtDL9ZEBsUkhoFt.53Xp87izZiPdonGsDK/ocY6KT6Dndz6'),
(7, 'raiful@gmail.com', 'Samma', 'Samma'),
(8, 'saifultanim9@gmail.com', 'Alexi', '$2y$10$uySk4TMitNgbehZOk0.7Z.pwzc.vCF9T/BgZyH2nmNWV6OlRap3TC'),
(9, 'saffu@gmail.com', 'saif', '$2y$10$2PQXhpMfdRUKE/ksV2uG/.ORFO4HBtm6XmT/whWI1cvSSBYyLlPRy'),
(10, 'mamu@gmail.com', 'mamu', '$2y$10$GQ7YUVsEToT0cklPzCQME.XK1giuP0ofFWxjoPJasDLH3Vulf8fb2');

-- --------------------------------------------------------

--
-- Table structure for table `threads`
--

CREATE TABLE `threads` (
  `thread_id` int(8) NOT NULL,
  `thread_title` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `thread_desc` text COLLATE utf8_unicode_ci NOT NULL,
  `thread_cat_id` int(8) NOT NULL,
  `thread_user_id` int(8) NOT NULL,
  `thread_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `threads`
--

INSERT INTO `threads` (`thread_id`, `thread_title`, `thread_desc`, `thread_cat_id`, `thread_user_id`, `thread_date`) VALUES
(1, 'Unable to install Tensorflow', 'Unable to install tensorflow \r\nI was trying to install but its an error showing that is error :505 \r\nDue to your ai application numpy its can not be installed with file corrupted.', 1, 3, '2021-07-08 14:06:24'),
(2, 'Unable to install java gui apps ', 'Its says my files already build but every time i tried to fix but its an error lots off things are saying what do i do now?', 2, 4, '2021-07-08 14:08:16'),
(3, 'Python db error', 'Db flask sql alchemy error', 1, 5, '2021-07-08 19:30:29'),
(4, 'Flask db ', 'Hell', 1, 1, '2021-07-09 05:26:05'),
(5, 'Flask db er', 'Finding error', 1, 4, '2021-07-09 06:18:52'),
(6, 'Flask db App error', 'Helll', 4, 2, '2021-07-09 06:33:43'),
(7, 'Java gui', 'Database failed', 3, 1, '2021-07-09 06:36:44'),
(8, 'Java progmming syntax', 'Gui error', 3, 1, '2021-07-09 09:39:38'),
(9, 'Django sql err', 'Test', 1, 4, '2021-07-09 11:36:50'),
(10, 'Flask db er', 'Error', 4, 2, '2021-07-10 08:58:13'),
(11, 'Find', 'Eror finding', 4, 6, '2021-07-10 09:29:31'),
(12, 'Hi', 'Bhh', 2, 7, '2021-07-10 19:04:13'),
(13, 'Hi', 'Bhh', 2, 7, '2021-07-10 19:05:13'),
(14, 'How can i create ios app?', 'How to create an ios app in online please help me', 6, 7, '2021-07-13 19:19:56'),
(15, 'Java progmming syntax', 'hi', 5, 7, '2021-07-31 14:38:20'),
(16, 'laravel progmming syntax', 'yo', 8, 7, '2021-07-31 23:18:49');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`comment_id`);

--
-- Indexes for table `registrarion`
--
ALTER TABLE `registrarion`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `threads`
--
ALTER TABLE `threads`
  ADD PRIMARY KEY (`thread_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `cat_id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `comment_id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `registrarion`
--
ALTER TABLE `registrarion`
  MODIFY `sno` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `threads`
--
ALTER TABLE `threads`
  MODIFY `thread_id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
